# ELITE-BOT-
A simple WhatsApp bot to manage groups
