const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const welcome = require('./lib/welcome');
const antilink = require('./lib/antilink');
const commands = require('./lib/commands');
const { removeViewOnce } = require('./lib/viewonce');
const { menuHandler } = require('./lib/menu');

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { headless: true }
});

client.on('qr', qr => qrcode.generate(qr, { small: true }));
client.on('ready', () => console.log('✅ Elite Bot 😎 v3.0 is online!'));

client.on('message', async msg => {
    if (await antilink(msg)) return;
    await removeViewOnce(msg, client);
    await menuHandler(msg);
    await commands(msg, client);
});

client.on('group_join', async (notification) => {
    await welcome(notification, "welcome");
});

client.on('group_leave', async (notification) => {
    await welcome(notification, "goodbye");
});

client.initialize();