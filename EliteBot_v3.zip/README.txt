📱 Elite Bot 😎 v3.0 - Setup

1. Install Termux from F-Droid.
2. Open Termux and run:
   pkg update && pkg upgrade -y
   pkg install nodejs ffmpeg unzip git -y

3. Move EliteBot_v3.zip to your /sdcard/Download/
4. In Termux:
   cd /sdcard/Download
   unzip EliteBot_v3.zip
   cd EliteBot_v3
   npm install

5. Run the bot:
   node index.js

6. Scan QR Code with WhatsApp ➜ Linked Devices

Enjoy! Now with:
- AI (.ask, .translate, .summary)
- Media tools (.sticker, .mp3, .voicetotext, .texttovoice)
- File tools (.pdf2text, .img2text)
- Admin (.ban, .rules, .tagall)
- Web (.ytmp3, .wiki, .weather)